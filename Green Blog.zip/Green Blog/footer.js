// rickroll
var count = 1;
function check(){
    console.log(count)
    while(count<=9){
        if($("#it"+String(count)).is(":checked") == true){
                count+=1 ;
        }else{
            break;
        }
    }
    if(count==9){
        window.open('unknown.html','_blank')
        count=1
    }

}