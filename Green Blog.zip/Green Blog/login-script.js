function registershow(){
    $("#register-tab").addClass("actived")
    $("#login-tab").removeClass("actived")
    $("#login").slideUp();
    $("#register").slideDown();
    }
function loginshow(){
    $("#login-tab").addClass("actived")
    $("#register-tab").removeClass("actived")
    $("#register").slideUp();
    $("#login").slideDown();
    }
function defualt(){
    $("#register").hide();
    $("#login-tab").addClass("actived")
}